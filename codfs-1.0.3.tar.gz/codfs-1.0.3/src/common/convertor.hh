#ifndef CONVERTOR_HH_
#define CONVERTOR_HH_

uint64_t stringToByte(std::string sizeString);
std::string md5ToHex(unsigned char* hash);

#endif /* CONVERTOR_HH_ */
