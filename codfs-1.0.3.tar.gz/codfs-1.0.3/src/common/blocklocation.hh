#ifndef BLOCKLOCATION_HH_
#define BLOCKLOCATION_HH_

struct BlockLocation {
	uint32_t osdId;
	uint32_t blockId;
};

#endif /* BLOCKLOCATION_HH_ */
